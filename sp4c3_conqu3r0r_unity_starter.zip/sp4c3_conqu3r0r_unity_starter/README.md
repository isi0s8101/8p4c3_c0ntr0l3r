# 3mp!r3 0f $p4c3 — Unity Starter

Repo de démarrage pour un jeu **3D (pilotage / FPS vaisseau)** + **micro‑gestion/UI** avec pipeline **data‑driven** :

`CSV (Design) → Validation Python → JSON → Import Unity (ScriptableObjects)`

## Prérequis
- Unity Hub + Unity LTS (module Android)
- Android Studio (SDK/NDK) ou SDK fourni par Unity
- Git + Git LFS

## Dossiers
- `Game/` : projet Unity (à créer via Unity Hub dans ce dossier)
- `Data/tables_csv/` : tables CSV (source de vérité)
- `Data/tools/` : scripts Python offline (validation/export)
- `Design/` : docs design / specs
- `Docs/` : décisions techniques / conventions
- `Art/`, `Audio/` : sources d’assets

## Pipeline data
1. Dépose les CSV dans `Data/tables_csv/`
2. Exécute : `python Data/tools/validate_and_export.py`
3. Les JSON sont générés dans `Data/build/json/`

## Git LFS
Voir `.gitattributes` et exécuter `git lfs install`.

## Licence
À définir.
