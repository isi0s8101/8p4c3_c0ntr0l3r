# Decisions techniques (Decision Log)

- Moteur : Unity
- Cible : Android + PC
- Données gameplay : CSV (source) → JSON (build) → import Unity (à implémenter)
- Versioning : Git + LFS (migration Perforce possible plus tard)
