# Mise en route (local)

1) Installe Git LFS : https://git-lfs.com/
2) Dans le repo :
   - `git lfs install`
3) Crée le projet Unity via Unity Hub dans `Game/` (Add → New project → location = ce dossier)
4) Dépose tes CSV dans `Data/tables_csv/`
5) Génère JSON :
   - `python Data/tools/validate_and_export.py`

Ensuite on branchera l’import Unity (ScriptableObjects) + build Android.
