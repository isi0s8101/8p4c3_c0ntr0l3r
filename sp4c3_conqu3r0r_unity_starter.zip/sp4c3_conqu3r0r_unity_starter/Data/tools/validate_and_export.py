from __future__ import annotations
import csv
import json
import sys
from pathlib import Path

SEP = ";"

# Colonnes minimales attendues (ajuste au besoin)
REQUIRED = {
    "defense_modules_tiers_N1-N6.csv": ["module_id", "tier", "effet", "PE", "T", "incompatibilite"],
    "stations.csv": ["station_id", "name", "role"],
    "ordres_flotte.csv": ["order_id", "category", "label"],
    "parametres_tunables.csv": ["key", "min", "max", "default"],
}

def read_csv(path: Path) -> list[dict[str, str]]:
    # utf-8-sig gère le BOM Excel
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=SEP))

def require_cols(filename: str, rows: list[dict[str, str]]) -> None:
    if filename not in REQUIRED or not rows:
        return
    cols = set(rows[0].keys())
    missing = [c for c in REQUIRED[filename] if c not in cols]
    if missing:
        raise ValueError(f"{filename}: colonnes manquantes: {missing}")

def main(data_dir: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    tables: dict[str, list[dict[str, str]]] = {}
    for csv_path in sorted(data_dir.glob("*.csv")):
        rows = read_csv(csv_path)
        if rows:
            require_cols(csv_path.name, rows)
        tables[csv_path.name] = rows

    # Exemple de règle: incompatibilités doivent référencer un module existant (si table présente)
    mods = tables.get("defense_modules_tiers_N1-N6.csv", [])
    if mods:
        module_ids = {r.get("module_id","").strip() for r in mods if r.get("module_id")}
        for r in mods:
            inc = (r.get("incompatibilite") or "").strip()
            if inc and inc not in module_ids:
                raise ValueError(f"Incompatibilité inconnue: {inc} (dans module_id={r.get('module_id')})")

    # Export JSON (1 fichier par table)
    for name, rows in tables.items():
        out_path = out_dir / (name.replace(".csv", ".json"))
        out_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"OK: {len(tables)} tables exportées vers {out_dir}")

if __name__ == "__main__":
    data_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("Data/tables_csv")
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("Data/build/json")
    main(data_dir, out_dir)
